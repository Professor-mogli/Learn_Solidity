
  # Gym Management SaaS Plan

  This is a code bundle for Gym Management SaaS Plan. The original project is available at https://www.figma.com/design/xpRsuTz7LmpxjXqN1czXm6/Gym-Management-SaaS-Plan.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  