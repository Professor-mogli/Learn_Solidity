// Mock Data for Gym Management SaaS

export interface SubscriptionPack {
  id: string;
  name: string;
  duration: string;
  durationDays: number;
  price: number;
  maxMembers: number | null;
  features: string[];
  status: 'active' | 'inactive';
}

export interface GymOwner {
  id: string;
  ownerName: string;
  email: string;
  mobile: string;
  gymName: string;
  address: string;
  packId: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'expired' | 'disabled';
  password: string;
  description?: string;
  photo?: string;
}

export interface Member {
  id: string;
  gymId: string;
  fullName: string;
  mobile: string;
  email: string;
  address: string;
  planId: string;
  planName: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'expired' | 'expiring';
  photo?: string;
  notes?: string;
  memberId: string;
  qrData: string;
}

export interface AttendanceLog {
  id: string;
  memberId: string;
  memberName: string;
  gymId: string;
  date: string;
  checkInTime: string;
  status: 'present' | 'absent';
}

export interface Payment {
  id: string;
  gymId?: string;
  gymName?: string;
  memberId?: string;
  memberName?: string;
  amount: number;
  date: string;
  type: 'gym_subscription' | 'member_subscription';
  status: 'paid' | 'pending' | 'overdue';
}

export interface MemberPlan {
  id: string;
  gymId: string;
  name: string;
  duration: string;
  durationDays: number;
  price: number;
  features: string[];
  status: 'active' | 'inactive';
}

export const subscriptionPacks: SubscriptionPack[] = [
  {
    id: 'pack-1',
    name: 'Starter',
    duration: '1 Month',
    durationDays: 30,
    price: 2999,
    maxMembers: 50,
    features: ['Basic Dashboard', 'Member Management', 'QR Code System', 'Email Support'],
    status: 'active',
  },
  {
    id: 'pack-2',
    name: 'Professional',
    duration: '3 Months',
    durationDays: 90,
    price: 7999,
    maxMembers: 200,
    features: ['Advanced Dashboard', 'Member Management', 'QR Code System', 'Attendance Tracking', 'Reports', 'Priority Support'],
    status: 'active',
  },
  {
    id: 'pack-3',
    name: 'Enterprise',
    duration: '1 Year',
    durationDays: 365,
    price: 24999,
    maxMembers: null,
    features: ['Full Dashboard', 'Unlimited Members', 'QR Code System', 'Advanced Analytics', 'Custom Reports', 'API Access', '24/7 Support'],
    status: 'active',
  },
  {
    id: 'pack-4',
    name: 'Trial',
    duration: '14 Days',
    durationDays: 14,
    price: 0,
    maxMembers: 10,
    features: ['Basic Dashboard', 'Member Management', 'QR Code System'],
    status: 'active',
  },
];

export const gymOwners: GymOwner[] = [
  {
    id: 'gym-1',
    ownerName: 'Rajesh Kumar',
    email: 'rajesh@ironfit.com',
    mobile: '+91 98765 43210',
    gymName: 'Iron Fit Gym',
    address: '123 Main Street, Mumbai, MH 400001',
    packId: 'pack-3',
    startDate: '2025-01-15',
    endDate: '2026-01-15',
    status: 'active',
    password: 'gym123',
    description: 'Premium fitness center with modern equipment',
  },
  {
    id: 'gym-2',
    ownerName: 'Priya Sharma',
    email: 'priya@flexzone.com',
    mobile: '+91 98765 12345',
    gymName: 'Flex Zone',
    address: '456 Park Road, Delhi, DL 110001',
    packId: 'pack-2',
    startDate: '2025-11-01',
    endDate: '2026-02-01',
    status: 'active',
    password: 'gym456',
    description: 'Boutique fitness studio for women',
  },
  {
    id: 'gym-3',
    ownerName: 'Vikram Singh',
    email: 'vikram@powergym.com',
    mobile: '+91 87654 32109',
    gymName: 'Power Gym',
    address: '789 Lake View, Bangalore, KA 560001',
    packId: 'pack-1',
    startDate: '2025-10-01',
    endDate: '2025-11-01',
    status: 'expired',
    password: 'gym789',
  },
  {
    id: 'gym-4',
    ownerName: 'Anita Desai',
    email: 'anita@fitlife.com',
    mobile: '+91 76543 21098',
    gymName: 'Fit Life Studio',
    address: '321 Green Avenue, Pune, MH 411001',
    packId: 'pack-2',
    startDate: '2025-12-01',
    endDate: '2026-03-01',
    status: 'active',
    password: 'gym321',
    description: 'Yoga and fitness studio',
  },
  {
    id: 'gym-5',
    ownerName: 'Suresh Patel',
    email: 'suresh@musclemania.com',
    mobile: '+91 65432 10987',
    gymName: 'Muscle Mania',
    address: '654 Station Road, Ahmedabad, GJ 380001',
    packId: 'pack-3',
    startDate: '2025-06-01',
    endDate: '2026-06-01',
    status: 'disabled',
    password: 'gym654',
  },
];

export const members: Member[] = [
  {
    id: 'mem-1', gymId: 'gym-1', fullName: 'Amit Patel', mobile: '+91 99887 76655',
    email: 'amit@email.com', address: '101 Elm St, Mumbai', planId: 'mplan-1',
    planName: '3 Months Plan', startDate: '2025-12-01', endDate: '2026-03-01',
    status: 'active', memberId: 'IF-001', qrData: 'IF-001|gym-1|2026-03-01|active', notes: 'Morning batch',
  },
  {
    id: 'mem-2', gymId: 'gym-1', fullName: 'Sneha Gupta', mobile: '+91 99887 11223',
    email: 'sneha@email.com', address: '202 Oak Ave, Mumbai', planId: 'mplan-2',
    planName: '1 Month Plan', startDate: '2026-01-15', endDate: '2026-02-15',
    status: 'active', memberId: 'IF-002', qrData: 'IF-002|gym-1|2026-02-15|active', notes: 'Evening batch',
  },
  {
    id: 'mem-3', gymId: 'gym-1', fullName: 'Ravi Mehta', mobile: '+91 88776 55443',
    email: 'ravi@email.com', address: '303 Pine Rd, Mumbai', planId: 'mplan-3',
    planName: '1 Year Plan', startDate: '2025-06-01', endDate: '2026-06-01',
    status: 'active', memberId: 'IF-003', qrData: 'IF-003|gym-1|2026-06-01|active',
  },
  {
    id: 'mem-4', gymId: 'gym-1', fullName: 'Kavita Joshi', mobile: '+91 77665 44332',
    email: 'kavita@email.com', address: '404 Maple Ln, Mumbai', planId: 'mplan-1',
    planName: '3 Months Plan', startDate: '2025-11-01', endDate: '2026-02-01',
    status: 'expiring', memberId: 'IF-004', qrData: 'IF-004|gym-1|2026-02-01|active',
  },
  {
    id: 'mem-5', gymId: 'gym-1', fullName: 'Deepak Verma', mobile: '+91 66554 33221',
    email: 'deepak@email.com', address: '505 Cedar Dr, Mumbai', planId: 'mplan-2',
    planName: '1 Month Plan', startDate: '2025-12-15', endDate: '2026-01-15',
    status: 'expired', memberId: 'IF-005', qrData: 'IF-005|gym-1|2026-01-15|expired',
  },
  {
    id: 'mem-6', gymId: 'gym-1', fullName: 'Pooja Nair', mobile: '+91 55443 22110',
    email: 'pooja@email.com', address: '606 Birch Way, Mumbai', planId: 'mplan-3',
    planName: '1 Year Plan', startDate: '2025-08-01', endDate: '2026-08-01',
    status: 'active', memberId: 'IF-006', qrData: 'IF-006|gym-1|2026-08-01|active',
  },
  {
    id: 'mem-7', gymId: 'gym-1', fullName: 'Arjun Reddy', mobile: '+91 44332 11009',
    email: 'arjun@email.com', address: '707 Walnut St, Mumbai', planId: 'mplan-1',
    planName: '3 Months Plan', startDate: '2026-01-01', endDate: '2026-04-01',
    status: 'active', memberId: 'IF-007', qrData: 'IF-007|gym-1|2026-04-01|active', notes: 'Personal training',
  },
  {
    id: 'mem-8', gymId: 'gym-1', fullName: 'Meera Shah', mobile: '+91 33221 99887',
    email: 'meera@email.com', address: '808 Spruce Ct, Mumbai', planId: 'mplan-2',
    planName: '1 Month Plan', startDate: '2026-02-01', endDate: '2026-03-01',
    status: 'active', memberId: 'IF-008', qrData: 'IF-008|gym-1|2026-03-01|active',
  },
  {
    id: 'mem-9', gymId: 'gym-2', fullName: 'Neha Kapoor', mobile: '+91 22110 88776',
    email: 'neha@email.com', address: '123 Ring Rd, Delhi', planId: 'mplan-1',
    planName: '3 Months Plan', startDate: '2025-12-15', endDate: '2026-03-15',
    status: 'active', memberId: 'FZ-001', qrData: 'FZ-001|gym-2|2026-03-15|active',
  },
  {
    id: 'mem-10', gymId: 'gym-2', fullName: 'Rohit Agarwal', mobile: '+91 11009 77665',
    email: 'rohit@email.com', address: '456 MG Rd, Delhi', planId: 'mplan-2',
    planName: '1 Month Plan', startDate: '2026-01-20', endDate: '2026-02-20',
    status: 'expiring', memberId: 'FZ-002', qrData: 'FZ-002|gym-2|2026-02-20|active',
  },
];

export const memberPlans: MemberPlan[] = [
  {
    id: 'mplan-1', gymId: 'gym-1', name: '3 Months Plan', duration: '3 Months',
    durationDays: 90, price: 4500, features: ['Full Gym Access', 'Locker Room', 'Free WiFi'], status: 'active',
  },
  {
    id: 'mplan-2', gymId: 'gym-1', name: '1 Month Plan', duration: '1 Month',
    durationDays: 30, price: 1800, features: ['Full Gym Access', 'Locker Room'], status: 'active',
  },
  {
    id: 'mplan-3', gymId: 'gym-1', name: '1 Year Plan', duration: '1 Year',
    durationDays: 365, price: 15000, features: ['Full Gym Access', 'Locker Room', 'Free WiFi', 'Personal Trainer', 'Diet Plan'], status: 'active',
  },
  {
    id: 'mplan-4', gymId: 'gym-2', name: '3 Months Plan', duration: '3 Months',
    durationDays: 90, price: 5000, features: ['Full Gym Access', 'Yoga Classes', 'Locker Room'], status: 'active',
  },
];

const generateAttendanceLogs = (): AttendanceLog[] => {
  const logs: AttendanceLog[] = [];
  const gymMembers = members.filter(m => m.gymId === 'gym-1');
  const times = ['06:15 AM', '06:45 AM', '07:00 AM', '07:30 AM', '08:00 AM', '09:15 AM', '10:00 AM', '05:30 PM', '06:00 PM', '06:30 PM', '07:00 PM', '07:45 PM'];

  for (let day = 1; day <= 18; day++) {
    const dateStr = `2026-02-${day.toString().padStart(2, '0')}`;
    gymMembers.forEach((member, idx) => {
      const isPresent = Math.random() > 0.3;
      if (isPresent) {
        logs.push({
          id: `att-${dateStr}-${member.id}`,
          memberId: member.id,
          memberName: member.fullName,
          gymId: member.gymId,
          date: dateStr,
          checkInTime: times[(idx + day) % times.length],
          status: 'present',
        });
      }
    });
  }
  return logs;
};

export const attendanceLogs: AttendanceLog[] = generateAttendanceLogs();

export const payments: Payment[] = [
  { id: 'pay-1', gymName: 'Iron Fit Gym', gymId: 'gym-1', amount: 24999, date: '2025-01-15', type: 'gym_subscription', status: 'paid' },
  { id: 'pay-2', gymName: 'Flex Zone', gymId: 'gym-2', amount: 7999, date: '2025-11-01', type: 'gym_subscription', status: 'paid' },
  { id: 'pay-3', gymName: 'Power Gym', gymId: 'gym-3', amount: 2999, date: '2025-10-01', type: 'gym_subscription', status: 'paid' },
  { id: 'pay-4', gymName: 'Fit Life Studio', gymId: 'gym-4', amount: 7999, date: '2025-12-01', type: 'gym_subscription', status: 'paid' },
  { id: 'pay-5', gymName: 'Muscle Mania', gymId: 'gym-5', amount: 24999, date: '2025-06-01', type: 'gym_subscription', status: 'paid' },
  { id: 'pay-6', memberName: 'Amit Patel', memberId: 'mem-1', gymId: 'gym-1', amount: 4500, date: '2025-12-01', type: 'member_subscription', status: 'paid' },
  { id: 'pay-7', memberName: 'Sneha Gupta', memberId: 'mem-2', gymId: 'gym-1', amount: 1800, date: '2026-01-15', type: 'member_subscription', status: 'paid' },
  { id: 'pay-8', memberName: 'Ravi Mehta', memberId: 'mem-3', gymId: 'gym-1', amount: 15000, date: '2025-06-01', type: 'member_subscription', status: 'paid' },
  { id: 'pay-9', memberName: 'Kavita Joshi', memberId: 'mem-4', gymId: 'gym-1', amount: 4500, date: '2025-11-01', type: 'member_subscription', status: 'paid' },
  { id: 'pay-10', memberName: 'Arjun Reddy', memberId: 'mem-7', gymId: 'gym-1', amount: 4500, date: '2026-01-01', type: 'member_subscription', status: 'paid' },
];

export const revenueData = [
  { month: 'Sep', revenue: 8500 },
  { month: 'Oct', revenue: 12000 },
  { month: 'Nov', revenue: 15500 },
  { month: 'Dec', revenue: 21000 },
  { month: 'Jan', revenue: 18500 },
  { month: 'Feb', revenue: 14000 },
];

export const attendanceChartData = [
  { day: 'Mon', count: 45 },
  { day: 'Tue', count: 52 },
  { day: 'Wed', count: 48 },
  { day: 'Thu', count: 55 },
  { day: 'Fri', count: 42 },
  { day: 'Sat', count: 60 },
  { day: 'Sun', count: 25 },
];
