import React, { createContext, useContext, useState, useCallback } from 'react';
import { gymOwners, members } from '../data/mockData';

export type UserRole = 'super_admin' | 'gym_owner' | 'member';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  gymId?: string;
  gymName?: string;
}

interface AuthContextType {
  user: AuthUser | null;
  login: (email: string, password: string, role: UserRole) => boolean;
  memberLogin: (mobile: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);

  const login = useCallback((email: string, password: string, role: UserRole): boolean => {
    if (role === 'super_admin') {
      if (email === 'admin@gymmanager.com' && password === 'admin123') {
        setUser({ id: 'sa-1', name: 'Super Admin', email, role: 'super_admin' });
        return true;
      }
    } else if (role === 'gym_owner') {
      const owner = gymOwners.find(g => g.email === email && g.password === password);
      if (owner && owner.status === 'active') {
        setUser({
          id: owner.id,
          name: owner.ownerName,
          email: owner.email,
          role: 'gym_owner',
          gymId: owner.id,
          gymName: owner.gymName,
        });
        return true;
      }
    }
    return false;
  }, []);

  const memberLogin = useCallback((mobile: string): boolean => {
    const member = members.find(m => m.mobile.replace(/\s/g, '').includes(mobile.replace(/\s/g, '')));
    if (member && member.status !== 'expired') {
      const gym = gymOwners.find(g => g.id === member.gymId);
      setUser({
        id: member.id,
        name: member.fullName,
        email: member.email,
        role: 'member',
        gymId: member.gymId,
        gymName: gym?.gymName,
      });
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, memberLogin, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}
