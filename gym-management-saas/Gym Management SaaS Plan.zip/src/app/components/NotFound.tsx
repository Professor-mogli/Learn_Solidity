import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Home } from 'lucide-react';

export function NotFound() {
  const navigate = useNavigate();
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center text-center p-6">
      <p className="text-6xl mb-4">404</p>
      <h2 className="text-gray-800 mb-2">Page Not Found</h2>
      <p className="text-gray-500 text-sm mb-6">The page you're looking for doesn't exist.</p>
      <Button onClick={() => navigate('/')} variant="outline">
        <Home className="w-4 h-4 mr-2" /> Go Home
      </Button>
    </div>
  );
}
