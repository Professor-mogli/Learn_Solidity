import { useState } from 'react';
import { DollarSign, Search, Filter } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { payments } from '../../data/mockData';

export function SAPayments() {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<string>('all');

  const filtered = payments.filter(p => {
    const matchSearch = (p.gymName || '').toLowerCase().includes(search.toLowerCase()) ||
      (p.memberName || '').toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || p.type === filter;
    return matchSearch && matchFilter;
  });

  const totalPaid = payments.filter(p => p.status === 'paid').reduce((s, p) => s + p.amount, 0);
  const gymRevenue = payments.filter(p => p.type === 'gym_subscription' && p.status === 'paid').reduce((s, p) => s + p.amount, 0);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">Payments</h1>
        <p className="text-gray-500 text-sm">Track all payment transactions</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl text-gray-800">₹{totalPaid.toLocaleString()}</p>
                <p className="text-gray-400 text-xs">Total Revenue</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl text-gray-800">₹{gymRevenue.toLocaleString()}</p>
                <p className="text-gray-400 text-xs">Gym Subscriptions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl text-gray-800">₹{(totalPaid - gymRevenue).toLocaleString()}</p>
                <p className="text-gray-400 text-xs">Member Subscriptions</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardContent className="pt-5">
          <div className="flex flex-col sm:flex-row gap-3 mb-5">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input placeholder="Search payments..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <div className="flex gap-2">
              {[
                { key: 'all', label: 'All' },
                { key: 'gym_subscription', label: 'Gym' },
                { key: 'member_subscription', label: 'Member' },
              ].map(f => (
                <Button key={f.key} variant={filter === f.key ? 'default' : 'outline'} size="sm"
                  onClick={() => setFilter(f.key)}
                  className={filter === f.key ? 'bg-orange-500 hover:bg-orange-600 text-white' : ''}>
                  {f.label}
                </Button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-3 text-gray-500">ID</th>
                  <th className="text-left py-3 px-3 text-gray-500">Name</th>
                  <th className="text-left py-3 px-3 text-gray-500">Type</th>
                  <th className="text-left py-3 px-3 text-gray-500">Amount</th>
                  <th className="text-left py-3 px-3 text-gray-500">Date</th>
                  <th className="text-left py-3 px-3 text-gray-500">Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(pay => (
                  <tr key={pay.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                    <td className="py-3 px-3 text-gray-400">{pay.id}</td>
                    <td className="py-3 px-3 text-gray-800">{pay.gymName || pay.memberName}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        pay.type === 'gym_subscription' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'
                      }`}>
                        {pay.type === 'gym_subscription' ? 'Gym' : 'Member'}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-gray-800">₹{pay.amount.toLocaleString()}</td>
                    <td className="py-3 px-3 text-gray-600">{pay.date}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-700">
                        {pay.status.charAt(0).toUpperCase() + pay.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
