import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, Copy, Mail, MessageSquare, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { subscriptionPacks } from '../../data/mockData';
import { toast } from 'sonner';

export function CreateGymOwner() {
  const navigate = useNavigate();
  const [created, setCreated] = useState(false);
  const [form, setForm] = useState({
    ownerName: '', email: '', mobile: '', gymName: '', address: '',
    packId: '', startDate: '', password: '',
  });

  const generatePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    let pwd = '';
    for (let i = 0; i < 10; i++) pwd += chars.charAt(Math.floor(Math.random() * chars.length));
    setForm(prev => ({ ...prev, password: pwd }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.packId) { toast.error('Please select a subscription pack'); return; }
    setCreated(true);
    toast.success(`${form.gymName} has been created successfully!`);
  };

  const update = (key: string, value: string) => setForm(prev => ({ ...prev, [key]: value }));

  if (created) {
    return (
      <div className="max-w-lg mx-auto space-y-6">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">✓</span>
          </div>
          <h1 className="text-gray-800">Gym Owner Created!</h1>
          <p className="text-gray-500 text-sm mt-1">{form.gymName} has been successfully registered</p>
        </div>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div><p className="text-gray-400">Owner</p><p className="text-gray-800">{form.ownerName}</p></div>
              <div><p className="text-gray-400">Gym</p><p className="text-gray-800">{form.gymName}</p></div>
              <div><p className="text-gray-400">Email</p><p className="text-gray-800">{form.email}</p></div>
              <div><p className="text-gray-400">Password</p><p className="text-gray-800 font-mono">{form.password}</p></div>
            </div>
            <div className="flex gap-2 pt-3 border-t">
              <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(`Email: ${form.email}\nPassword: ${form.password}`); toast.success('Copied!'); }}>
                <Copy className="w-3 h-3 mr-1" /> Copy Credentials
              </Button>
              <Button size="sm" variant="outline" onClick={() => toast.success('Email sent!')}>
                <Mail className="w-3 h-3 mr-1" /> Send Email
              </Button>
              <Button size="sm" variant="outline" onClick={() => toast.success('WhatsApp sent!')}>
                <MessageSquare className="w-3 h-3 mr-1" /> WhatsApp
              </Button>
            </div>
          </CardContent>
        </Card>
        <div className="flex gap-3 justify-center">
          <Button variant="outline" onClick={() => { setCreated(false); setForm({ ownerName: '', email: '', mobile: '', gymName: '', address: '', packId: '', startDate: '', password: '' }); }}>
            Create Another
          </Button>
          <Button onClick={() => navigate('/admin/gym-owners')} className="bg-orange-500 hover:bg-orange-600 text-white">
            View All Gyms
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/admin/gym-owners')}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-gray-800">Create Gym Owner</h1>
          <p className="text-gray-500 text-sm">Register a new gym on the platform</p>
        </div>
      </div>

      <Card className="border-none shadow-sm">
        <CardContent className="pt-5">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Owner Name *</label>
                <Input value={form.ownerName} onChange={e => update('ownerName', e.target.value)} placeholder="Full name" required />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Gym Name *</label>
                <Input value={form.gymName} onChange={e => update('gymName', e.target.value)} placeholder="Gym name" required />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Email *</label>
                <Input type="email" value={form.email} onChange={e => update('email', e.target.value)} placeholder="email@example.com" required />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Mobile *</label>
                <Input value={form.mobile} onChange={e => update('mobile', e.target.value)} placeholder="+91 XXXXX XXXXX" required />
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm text-gray-600 mb-1.5 block">Address *</label>
                <Input value={form.address} onChange={e => update('address', e.target.value)} placeholder="Full address" required />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Subscription Pack *</label>
                <select
                  value={form.packId}
                  onChange={e => update('packId', e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white"
                  required
                >
                  <option value="">Select pack</option>
                  {subscriptionPacks.filter(p => p.status === 'active').map(p => (
                    <option key={p.id} value={p.id}>{p.name} - {p.duration} (₹{p.price.toLocaleString()})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Start Date *</label>
                <Input type="date" value={form.startDate} onChange={e => update('startDate', e.target.value)} required />
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm text-gray-600 mb-1.5 block">Password *</label>
                <div className="flex gap-2">
                  <Input value={form.password} onChange={e => update('password', e.target.value)} placeholder="Password" required />
                  <Button type="button" variant="outline" onClick={generatePassword}>
                    <RefreshCw className="w-4 h-4 mr-1" /> Auto
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => navigate('/admin/gym-owners')}>Cancel</Button>
              <Button type="submit" className="bg-orange-500 hover:bg-orange-600 text-white">Create Gym Owner</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
