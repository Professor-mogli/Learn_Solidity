import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Search, Plus, Eye, Edit, Trash2, Power, PowerOff, Filter, Copy, Mail, MessageSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { gymOwners as initialGyms, subscriptionPacks, GymOwner } from '../../data/mockData';
import { toast } from 'sonner';

export function GymOwnersList() {
  const navigate = useNavigate();
  const [gyms, setGyms] = useState<GymOwner[]>(initialGyms);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<string>('all');
  const [viewGym, setViewGym] = useState<GymOwner | null>(null);

  const filtered = gyms.filter(g => {
    const matchSearch = g.gymName.toLowerCase().includes(search.toLowerCase()) ||
      g.ownerName.toLowerCase().includes(search.toLowerCase()) ||
      g.email.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || g.status === filter;
    return matchSearch && matchFilter;
  });

  const toggleStatus = (id: string) => {
    setGyms(prev => prev.map(g => {
      if (g.id === id) {
        const newStatus = g.status === 'active' ? 'disabled' : 'active';
        toast.success(`${g.gymName} has been ${newStatus === 'active' ? 'activated' : 'deactivated'}`);
        return { ...g, status: newStatus as GymOwner['status'] };
      }
      return g;
    }));
  };

  const deleteGym = (id: string) => {
    const gym = gyms.find(g => g.id === id);
    setGyms(prev => prev.filter(g => g.id !== id));
    toast.success(`${gym?.gymName} has been deleted`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-800">Gym Owners</h1>
          <p className="text-gray-500 text-sm">Manage all registered gym owners</p>
        </div>
        <Button onClick={() => navigate('/admin/gym-owners/create')} className="bg-orange-500 hover:bg-orange-600 text-white">
          <Plus className="w-4 h-4 mr-2" /> Create Gym Owner
        </Button>
      </div>

      <Card className="border-none shadow-sm">
        <CardContent className="pt-5">
          <div className="flex flex-col sm:flex-row gap-3 mb-5">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input placeholder="Search gyms, owners, emails..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <div className="flex gap-2">
              {['all', 'active', 'expired', 'disabled'].map(f => (
                <Button key={f} variant={filter === f ? 'default' : 'outline'} size="sm" onClick={() => setFilter(f)}
                  className={filter === f ? 'bg-orange-500 hover:bg-orange-600 text-white' : ''}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </Button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-3 text-gray-500">Gym Name</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden md:table-cell">Owner</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden lg:table-cell">Email</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden lg:table-cell">Mobile</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden sm:table-cell">Pack</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden xl:table-cell">Start</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden xl:table-cell">End</th>
                  <th className="text-left py-3 px-3 text-gray-500">Status</th>
                  <th className="text-left py-3 px-3 text-gray-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(gym => {
                  const pack = subscriptionPacks.find(p => p.id === gym.packId);
                  return (
                    <tr key={gym.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                      <td className="py-3 px-3">
                        <div>
                          <p className="text-gray-800">{gym.gymName}</p>
                          <p className="text-gray-400 text-xs md:hidden">{gym.ownerName}</p>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-gray-600 hidden md:table-cell">{gym.ownerName}</td>
                      <td className="py-3 px-3 text-gray-600 hidden lg:table-cell">{gym.email}</td>
                      <td className="py-3 px-3 text-gray-600 hidden lg:table-cell">{gym.mobile}</td>
                      <td className="py-3 px-3 text-gray-600 hidden sm:table-cell">{pack?.name}</td>
                      <td className="py-3 px-3 text-gray-600 hidden xl:table-cell">{gym.startDate}</td>
                      <td className="py-3 px-3 text-gray-600 hidden xl:table-cell">{gym.endDate}</td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          gym.status === 'active' ? 'bg-green-100 text-green-700' :
                          gym.status === 'expired' ? 'bg-red-100 text-red-700' :
                          'bg-orange-100 text-orange-700'
                        }`}>
                          {gym.status.charAt(0).toUpperCase() + gym.status.slice(1)}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setViewGym(gym)}>
                            <Eye className="w-4 h-4 text-gray-500" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => navigate(`/admin/gym-owners/edit/${gym.id}`)}>
                            <Edit className="w-4 h-4 text-blue-500" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStatus(gym.id)}>
                            {gym.status === 'active' ? <PowerOff className="w-4 h-4 text-orange-500" /> : <Power className="w-4 h-4 text-green-500" />}
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteGym(gym.id)}>
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <p className="text-center text-gray-400 py-10">No gym owners found</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* View Dialog */}
      <Dialog open={!!viewGym} onOpenChange={() => setViewGym(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{viewGym?.gymName}</DialogTitle>
            <DialogDescription>Gym owner details</DialogDescription>
          </DialogHeader>
          {viewGym && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-gray-400">Owner</p><p className="text-gray-800">{viewGym.ownerName}</p></div>
                <div><p className="text-gray-400">Email</p><p className="text-gray-800">{viewGym.email}</p></div>
                <div><p className="text-gray-400">Mobile</p><p className="text-gray-800">{viewGym.mobile}</p></div>
                <div><p className="text-gray-400">Status</p><p className={viewGym.status === 'active' ? 'text-green-600' : 'text-red-600'}>{viewGym.status.toUpperCase()}</p></div>
                <div><p className="text-gray-400">Start Date</p><p className="text-gray-800">{viewGym.startDate}</p></div>
                <div><p className="text-gray-400">End Date</p><p className="text-gray-800">{viewGym.endDate}</p></div>
              </div>
              <div><p className="text-gray-400">Address</p><p className="text-gray-800">{viewGym.address}</p></div>
              <div><p className="text-gray-400">Pack</p><p className="text-gray-800">{subscriptionPacks.find(p => p.id === viewGym.packId)?.name}</p></div>
              <div className="flex gap-2 pt-3 border-t">
                <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(`Email: ${viewGym.email}\nPassword: ${viewGym.password}`); toast.success('Credentials copied!'); }}>
                  <Copy className="w-3 h-3 mr-1" /> Copy Credentials
                </Button>
                <Button size="sm" variant="outline" onClick={() => toast.success('Email sent!')}>
                  <Mail className="w-3 h-3 mr-1" /> Email
                </Button>
                <Button size="sm" variant="outline" onClick={() => toast.success('WhatsApp message sent!')}>
                  <MessageSquare className="w-3 h-3 mr-1" /> WhatsApp
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
