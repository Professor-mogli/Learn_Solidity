import { useState } from 'react';
import { Save, Bell, Shield, Palette } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Switch } from '../ui/switch';
import { toast } from 'sonner';

export function SASettings() {
  const [platformName, setPlatformName] = useState('GymManager Pro');
  const [adminEmail, setAdminEmail] = useState('admin@gymmanager.com');
  const [notifExpiry, setNotifExpiry] = useState(true);
  const [notifPayment, setNotifPayment] = useState(true);
  const [notifNewGym, setNotifNewGym] = useState(true);
  const [autoDeactivate, setAutoDeactivate] = useState(true);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-gray-800">Settings</h1>
        <p className="text-gray-500 text-sm">Manage platform configuration</p>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700 flex items-center gap-2">
            <Palette className="w-4 h-4" /> General Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Platform Name</label>
            <Input value={platformName} onChange={e => setPlatformName(e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Admin Email</label>
            <Input type="email" value={adminEmail} onChange={e => setAdminEmail(e.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700 flex items-center gap-2">
            <Bell className="w-4 h-4" /> Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[
            { label: 'Expiry Notifications', desc: 'Get notified before gym subscriptions expire', value: notifExpiry, setter: setNotifExpiry },
            { label: 'Payment Notifications', desc: 'Get notified for new payments', value: notifPayment, setter: setNotifPayment },
            { label: 'New Gym Notifications', desc: 'Get notified when new gyms register', value: notifNewGym, setter: setNotifNewGym },
          ].map(({ label, desc, value, setter }) => (
            <div key={label} className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-800">{label}</p>
                <p className="text-xs text-gray-400">{desc}</p>
              </div>
              <Switch checked={value} onCheckedChange={setter} />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700 flex items-center gap-2">
            <Shield className="w-4 h-4" /> Security & Automation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-800">Auto-deactivate Expired Gyms</p>
              <p className="text-xs text-gray-400">Automatically block gym access when subscription expires</p>
            </div>
            <Switch checked={autoDeactivate} onCheckedChange={setAutoDeactivate} />
          </div>
        </CardContent>
      </Card>

      <Button onClick={() => toast.success('Settings saved!')} className="bg-orange-500 hover:bg-orange-600 text-white">
        <Save className="w-4 h-4 mr-2" /> Save Settings
      </Button>
    </div>
  );
}
