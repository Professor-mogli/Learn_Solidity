import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { gymOwners, members, payments, revenueData } from '../../data/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';

const membersByGym = gymOwners.map(g => ({
  gym: g.gymName.split(' ').slice(0, 2).join(' '),
  members: members.filter(m => m.gymId === g.id).length,
}));

const monthlySignups = [
  { month: 'Sep', gyms: 1, members: 12 },
  { month: 'Oct', gyms: 2, members: 18 },
  { month: 'Nov', gyms: 1, members: 22 },
  { month: 'Dec', gyms: 1, members: 28 },
  { month: 'Jan', gyms: 0, members: 15 },
  { month: 'Feb', gyms: 0, members: 10 },
];

export function SAReports() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">Reports & Analytics</h1>
        <p className="text-gray-500 text-sm">Platform-wide insights and metrics</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">{gymOwners.length}</p>
            <p className="text-gray-400 text-xs mt-1">Total Gyms</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">{members.length}</p>
            <p className="text-gray-400 text-xs mt-1">Total Members</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">₹{(payments.reduce((s, p) => s + p.amount, 0) / 1000).toFixed(0)}K</p>
            <p className="text-gray-400 text-xs mt-1">Total Revenue</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">{members.filter(m => m.status === 'active').length}</p>
            <p className="text-gray-400 text-xs mt-1">Active Members</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(val: number) => `₹${val.toLocaleString()}`} />
                <Area type="monotone" dataKey="revenue" stroke="#f97316" fill="#fed7aa" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Members by Gym</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={membersByGym}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="gym" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="members" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Monthly Signups</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={monthlySignups}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Line type="monotone" dataKey="gyms" stroke="#f97316" strokeWidth={2} name="Gyms" />
                <Line type="monotone" dataKey="members" stroke="#3b82f6" strokeWidth={2} name="Members" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
