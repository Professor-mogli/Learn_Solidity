import { Building2, Activity, AlertTriangle, DollarSign, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { gymOwners, payments, revenueData, subscriptionPacks } from '../../data/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const totalGyms = gymOwners.length;
const activeGyms = gymOwners.filter(g => g.status === 'active').length;
const inactiveGyms = gymOwners.filter(g => g.status !== 'active').length;
const totalRevenue = payments.filter(p => p.type === 'gym_subscription').reduce((s, p) => s + p.amount, 0);
const expiringThisMonth = gymOwners.filter(g => {
  const end = new Date(g.endDate);
  const now = new Date();
  return end.getMonth() === now.getMonth() && end.getFullYear() === now.getFullYear();
}).length;

const statusData = [
  { name: 'Active', value: activeGyms, color: '#22c55e' },
  { name: 'Expired', value: gymOwners.filter(g => g.status === 'expired').length, color: '#ef4444' },
  { name: 'Disabled', value: gymOwners.filter(g => g.status === 'disabled').length, color: '#f59e0b' },
];

const cards = [
  { label: 'Total Gyms', value: totalGyms, icon: Building2, color: 'bg-blue-500', lightColor: 'bg-blue-50 text-blue-600' },
  { label: 'Active Gyms', value: activeGyms, icon: Activity, color: 'bg-green-500', lightColor: 'bg-green-50 text-green-600' },
  { label: 'Inactive Gyms', value: inactiveGyms, icon: AlertTriangle, color: 'bg-red-500', lightColor: 'bg-red-50 text-red-600' },
  { label: 'Total Revenue', value: `₹${(totalRevenue / 1000).toFixed(1)}K`, icon: DollarSign, color: 'bg-purple-500', lightColor: 'bg-purple-50 text-purple-600' },
  { label: 'Expiring This Month', value: expiringThisMonth, icon: Clock, color: 'bg-orange-500', lightColor: 'bg-orange-50 text-orange-600' },
];

export function SADashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">Dashboard</h1>
        <p className="text-gray-500 text-sm">Welcome back, Super Admin</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {cards.map(({ label, value, icon: Icon, lightColor }) => (
          <Card key={label} className="border-none shadow-sm">
            <CardContent className="pt-5 pb-4">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${lightColor}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <TrendingUp className="w-4 h-4 text-green-500" />
              </div>
              <p className="text-2xl text-gray-800">{value}</p>
              <p className="text-gray-500 text-xs mt-1">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Revenue Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(val: number) => `₹${val.toLocaleString()}`} />
                <Bar dataKey="revenue" fill="#f97316" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Gym Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                  {statusData.map((entry) => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700">Recent Gym Registrations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-3 text-gray-500">Gym Name</th>
                  <th className="text-left py-3 px-3 text-gray-500">Owner</th>
                  <th className="text-left py-3 px-3 text-gray-500">Pack</th>
                  <th className="text-left py-3 px-3 text-gray-500">End Date</th>
                  <th className="text-left py-3 px-3 text-gray-500">Status</th>
                </tr>
              </thead>
              <tbody>
                {gymOwners.map(gym => {
                  const pack = subscriptionPacks.find(p => p.id === gym.packId);
                  return (
                    <tr key={gym.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                      <td className="py-3 px-3 text-gray-800">{gym.gymName}</td>
                      <td className="py-3 px-3 text-gray-600">{gym.ownerName}</td>
                      <td className="py-3 px-3 text-gray-600">{pack?.name}</td>
                      <td className="py-3 px-3 text-gray-600">{gym.endDate}</td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          gym.status === 'active' ? 'bg-green-100 text-green-700' :
                          gym.status === 'expired' ? 'bg-red-100 text-red-700' :
                          'bg-orange-100 text-orange-700'
                        }`}>
                          {gym.status.charAt(0).toUpperCase() + gym.status.slice(1)}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
