import { useState } from 'react';
import { Plus, Edit, Trash2, Check, X } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { subscriptionPacks as initialPacks, SubscriptionPack } from '../../data/mockData';
import { toast } from 'sonner';

export function SASubscriptionPacks() {
  const [packs, setPacks] = useState<SubscriptionPack[]>(initialPacks);
  const [showCreate, setShowCreate] = useState(false);
  const [editPack, setEditPack] = useState<SubscriptionPack | null>(null);
  const [form, setForm] = useState({
    name: '', duration: '', durationDays: '', price: '', maxMembers: '', features: '',
  });

  const resetForm = () => setForm({ name: '', duration: '', durationDays: '', price: '', maxMembers: '', features: '' });

  const openEdit = (pack: SubscriptionPack) => {
    setEditPack(pack);
    setForm({
      name: pack.name, duration: pack.duration, durationDays: String(pack.durationDays),
      price: String(pack.price), maxMembers: pack.maxMembers ? String(pack.maxMembers) : '',
      features: pack.features.join(', '),
    });
    setShowCreate(true);
  };

  const handleSave = () => {
    const newPack: SubscriptionPack = {
      id: editPack?.id || `pack-${Date.now()}`,
      name: form.name, duration: form.duration, durationDays: Number(form.durationDays),
      price: Number(form.price), maxMembers: form.maxMembers ? Number(form.maxMembers) : null,
      features: form.features.split(',').map(f => f.trim()).filter(Boolean),
      status: 'active',
    };
    if (editPack) {
      setPacks(prev => prev.map(p => p.id === editPack.id ? newPack : p));
      toast.success('Pack updated!');
    } else {
      setPacks(prev => [...prev, newPack]);
      toast.success('Pack created!');
    }
    setShowCreate(false);
    setEditPack(null);
    resetForm();
  };

  const deletePack = (id: string) => {
    setPacks(prev => prev.filter(p => p.id !== id));
    toast.success('Pack deleted');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-800">Subscription Packs</h1>
          <p className="text-gray-500 text-sm">Manage platform subscription packages</p>
        </div>
        <Button onClick={() => { resetForm(); setEditPack(null); setShowCreate(true); }} className="bg-orange-500 hover:bg-orange-600 text-white">
          <Plus className="w-4 h-4 mr-2" /> Create Pack
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {packs.map(pack => (
          <Card key={pack.id} className="border-none shadow-sm relative overflow-hidden">
            {pack.price === 0 && <div className="absolute top-3 right-3 bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full">Free</div>}
            <CardContent className="pt-5">
              <h3 className="text-gray-800 mb-1">{pack.name}</h3>
              <p className="text-3xl text-gray-800">₹{pack.price.toLocaleString()}</p>
              <p className="text-gray-400 text-xs mb-4">{pack.duration}</p>
              <ul className="space-y-2 mb-4">
                {pack.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500 shrink-0" /> {f}
                  </li>
                ))}
                {pack.maxMembers && (
                  <li className="flex items-center gap-2 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500 shrink-0" /> Up to {pack.maxMembers} members
                  </li>
                )}
              </ul>
              <div className="flex gap-2 pt-3 border-t">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => openEdit(pack)}>
                  <Edit className="w-3 h-3 mr-1" /> Edit
                </Button>
                <Button size="sm" variant="outline" className="text-red-500 hover:text-red-600" onClick={() => deletePack(pack.id)}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editPack ? 'Edit Pack' : 'Create Pack'}</DialogTitle>
            <DialogDescription>Fill in the pack details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-600 mb-1 block">Pack Name</label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g., Premium" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm text-gray-600 mb-1 block">Duration Label</label>
                <Input value={form.duration} onChange={e => setForm({ ...form, duration: e.target.value })} placeholder="e.g., 3 Months" />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1 block">Duration (Days)</label>
                <Input type="number" value={form.durationDays} onChange={e => setForm({ ...form, durationDays: e.target.value })} placeholder="90" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm text-gray-600 mb-1 block">Price (₹)</label>
                <Input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} placeholder="9999" />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1 block">Max Members (Optional)</label>
                <Input type="number" value={form.maxMembers} onChange={e => setForm({ ...form, maxMembers: e.target.value })} placeholder="Unlimited" />
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-600 mb-1 block">Features (comma separated)</label>
              <Input value={form.features} onChange={e => setForm({ ...form, features: e.target.value })} placeholder="Feature 1, Feature 2, ..." />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button onClick={handleSave} className="bg-orange-500 hover:bg-orange-600 text-white">
                {editPack ? 'Update' : 'Create'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
