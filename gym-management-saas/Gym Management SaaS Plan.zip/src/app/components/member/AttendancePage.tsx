import { useMemo, useState } from 'react';
import { CalendarDays, TrendingUp, BarChart3 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { useAuth } from '../../context/AuthContext';
import { attendanceLogs } from '../../data/mockData';
import { Button } from '../ui/button';

export function MemberAttendancePage() {
  const { user } = useAuth();
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');
  const [selectedMonth, setSelectedMonth] = useState('2026-02');

  const monthLogs = attendanceLogs.filter(
    a => a.memberId === user?.id && a.date.startsWith(selectedMonth)
  );

  const stats = useMemo(() => {
    const year = parseInt(selectedMonth.split('-')[0]);
    const month = parseInt(selectedMonth.split('-')[1]);
    const daysInMonth = new Date(year, month, 0).getDate();
    const today = selectedMonth === '2026-02' ? 18 : daysInMonth;
    const totalDays = Math.min(today, daysInMonth);
    const attended = monthLogs.length;
    const missed = totalDays - attended;
    const percentage = totalDays > 0 ? Math.round((attended / totalDays) * 100) : 0;
    return { daysInMonth, totalDays, attended, missed, percentage };
  }, [monthLogs, selectedMonth]);

  const calendarDays = useMemo(() => {
    const year = parseInt(selectedMonth.split('-')[0]);
    const month = parseInt(selectedMonth.split('-')[1]);
    const daysInMonth = new Date(year, month, 0).getDate();
    const today = selectedMonth === '2026-02' ? 18 : daysInMonth;

    const days: { day: number; status: 'present' | 'absent' | 'none' }[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${selectedMonth}-${d.toString().padStart(2, '0')}`;
      if (d > today) {
        days.push({ day: d, status: 'none' });
      } else if (monthLogs.some(l => l.date === dateStr)) {
        days.push({ day: d, status: 'present' });
      } else {
        days.push({ day: d, status: 'absent' });
      }
    }
    return days;
  }, [monthLogs, selectedMonth]);

  const firstDayOffset = new Date(`${selectedMonth}-01`).getDay();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-800">My Attendance</h1>
          <p className="text-gray-500 text-sm">Track your gym visits</p>
        </div>
        <input
          type="month"
          value={selectedMonth}
          onChange={e => setSelectedMonth(e.target.value)}
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white"
        />
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3 text-center">
            <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center mx-auto mb-2">
              <CalendarDays className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl text-green-700">{stats.attended}</p>
            <p className="text-xs text-gray-400">Days Attended</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3 text-center">
            <div className="w-10 h-10 bg-red-50 rounded-lg flex items-center justify-center mx-auto mb-2">
              <CalendarDays className="w-5 h-5 text-red-600" />
            </div>
            <p className="text-2xl text-red-700">{stats.missed}</p>
            <p className="text-xs text-gray-400">Days Missed</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3 text-center">
            <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center mx-auto mb-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
            <p className="text-2xl text-blue-700">{stats.percentage}%</p>
            <p className="text-xs text-gray-400">Attendance Rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <Card className="border-none shadow-sm">
        <CardContent className="pt-4 pb-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Monthly Progress</span>
            <span className="text-sm text-gray-800">{stats.attended}/{stats.totalDays} days</span>
          </div>
          <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                stats.percentage >= 70 ? 'bg-green-500' : stats.percentage >= 40 ? 'bg-orange-500' : 'bg-red-500'
              }`}
              style={{ width: `${stats.percentage}%` }}
            />
          </div>
        </CardContent>
      </Card>

      {/* View Toggle */}
      <div className="flex gap-2">
        <Button
          variant={viewMode === 'calendar' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setViewMode('calendar')}
          className={viewMode === 'calendar' ? 'bg-green-600 hover:bg-green-700 text-white' : ''}
        >
          Calendar View
        </Button>
        <Button
          variant={viewMode === 'list' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setViewMode('list')}
          className={viewMode === 'list' ? 'bg-green-600 hover:bg-green-700 text-white' : ''}
        >
          List View
        </Button>
      </div>

      {viewMode === 'calendar' ? (
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            <div className="grid grid-cols-7 gap-2 text-center">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                <span key={d} className="text-xs text-gray-400 py-2">{d}</span>
              ))}
              {Array.from({ length: firstDayOffset }).map((_, i) => (
                <span key={`empty-${i}`} />
              ))}
              {calendarDays.map(({ day, status }) => (
                <div
                  key={day}
                  className={`aspect-square rounded-xl flex flex-col items-center justify-center text-sm ${
                    status === 'present'
                      ? 'bg-green-500 text-white'
                      : status === 'absent'
                      ? 'bg-red-50 text-red-600'
                      : 'bg-gray-50 text-gray-300'
                  }`}
                >
                  {day}
                  {status === 'present' && <span className="w-1.5 h-1.5 bg-white rounded-full mt-0.5" />}
                  {status === 'absent' && <span className="w-1.5 h-1.5 bg-red-400 rounded-full mt-0.5" />}
                </div>
              ))}
            </div>

            <div className="flex gap-6 mt-4 text-xs text-gray-400 justify-center">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-green-500" /> Present
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-red-50 border border-red-200" /> Absent
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-gray-50 border" /> Future
              </span>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            {monthLogs.length > 0 ? (
              <div className="space-y-2">
                {monthLogs.map(log => (
                  <div key={log.id} className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <CalendarDays className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-800">{log.date}</p>
                        <p className="text-xs text-gray-400">{new Date(log.date).toLocaleDateString('en-US', { weekday: 'long' })}</p>
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">{log.checkInTime}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-400 py-8">No attendance records for this month</p>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
