import { useState } from 'react';
import { Save, Camera, User } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { useAuth } from '../../context/AuthContext';
import { members, gymOwners } from '../../data/mockData';
import { toast } from 'sonner';

export function MemberProfile() {
  const { user } = useAuth();
  const member = members.find(m => m.id === user?.id);
  const gym = gymOwners.find(g => g.id === member?.gymId);

  const [fullName, setFullName] = useState(member?.fullName || '');
  const [mobile, setMobile] = useState(member?.mobile || '');
  const [email, setEmail] = useState(member?.email || '');
  const [address, setAddress] = useState(member?.address || '');

  if (!member) return <p className="text-center text-gray-400 py-20">Member not found</p>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">My Profile</h1>
        <p className="text-gray-500 text-sm">Update your personal information</p>
      </div>

      {/* Profile Photo */}
      <Card className="border-none shadow-sm">
        <CardContent className="pt-5">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-green-600" />
              </div>
              <button className="absolute -bottom-1 -right-1 w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center">
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <div>
              <p className="text-gray-800">{member.fullName}</p>
              <p className="text-gray-400 text-sm">ID: {member.memberId}</p>
              <p className="text-gray-400 text-sm">{gym?.gymName}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal Info */}
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700">Personal Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Full Name</label>
            <Input value={fullName} onChange={e => setFullName(e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Mobile</label>
            <Input value={mobile} onChange={e => setMobile(e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Email</label>
            <Input type="email" value={email} onChange={e => setEmail(e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Address</label>
            <Input value={address} onChange={e => setAddress(e.target.value)} />
          </div>
        </CardContent>
      </Card>

      {/* Subscription Info */}
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700">Subscription Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-400">Plan</p>
              <p className="text-gray-800">{member.planName}</p>
            </div>
            <div>
              <p className="text-gray-400">Status</p>
              <p className={
                member.status === 'active' ? 'text-green-600' :
                member.status === 'expiring' ? 'text-orange-600' : 'text-red-600'
              }>
                {member.status.toUpperCase()}
              </p>
            </div>
            <div>
              <p className="text-gray-400">Start Date</p>
              <p className="text-gray-800">{member.startDate}</p>
            </div>
            <div>
              <p className="text-gray-400">End Date</p>
              <p className="text-gray-800">{member.endDate}</p>
            </div>
            <div>
              <p className="text-gray-400">Gym</p>
              <p className="text-gray-800">{gym?.gymName}</p>
            </div>
            <div>
              <p className="text-gray-400">Gym Address</p>
              <p className="text-gray-800">{gym?.address}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Button onClick={() => toast.success('Profile updated!')} className="w-full bg-green-600 hover:bg-green-700 text-white">
        <Save className="w-4 h-4 mr-2" /> Save Changes
      </Button>
    </div>
  );
}
