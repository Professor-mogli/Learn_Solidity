import { useState, useMemo } from 'react';
import { CreditCard, Calendar, Clock, Building2, QrCode, CalendarCheck, X } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { useAuth } from '../../context/AuthContext';
import { members, gymOwners, attendanceLogs } from '../../data/mockData';
import { QRCodeSVG } from 'qrcode.react';

export function MemberDashboard() {
  const { user } = useAuth();
  const [showQR, setShowQR] = useState(false);

  const member = members.find(m => m.id === user?.id);
  const gym = gymOwners.find(g => g.id === member?.gymId);

  const daysLeft = useMemo(() => {
    if (!member) return 0;
    const end = new Date(member.endDate);
    const now = new Date('2026-02-18');
    return Math.max(0, Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)));
  }, [member]);

  const monthLogs = attendanceLogs.filter(
    a => a.memberId === user?.id && a.date.startsWith('2026-02')
  );
  const lastVisit = monthLogs.length > 0 ? monthLogs[monthLogs.length - 1].date : 'N/A';

  if (!member) return <p className="text-center text-gray-400 py-20">Member data not found</p>;

  const expiryColor = daysLeft > 30 ? 'text-green-600' : daysLeft > 7 ? 'text-orange-600' : 'text-red-600';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">Welcome, {member.fullName}!</h1>
        <p className="text-gray-500 text-sm">Member ID: {member.memberId}</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 bg-blue-50 rounded-lg flex items-center justify-center">
                <CreditCard className="w-4 h-4 text-blue-600" />
              </div>
            </div>
            <p className="text-sm text-gray-800">{member.planName}</p>
            <p className="text-xs text-gray-400">Subscription Plan</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 bg-red-50 rounded-lg flex items-center justify-center">
                <Calendar className="w-4 h-4 text-red-600" />
              </div>
            </div>
            <p className="text-sm text-gray-800">{member.endDate}</p>
            <p className="text-xs text-gray-400">Expiry Date</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 bg-orange-50 rounded-lg flex items-center justify-center">
                <Clock className="w-4 h-4 text-orange-600" />
              </div>
            </div>
            <p className={`text-sm ${expiryColor}`}>{daysLeft} days</p>
            <p className="text-xs text-gray-400">Days Remaining</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 bg-purple-50 rounded-lg flex items-center justify-center">
                <Building2 className="w-4 h-4 text-purple-600" />
              </div>
            </div>
            <p className="text-sm text-gray-800">{gym?.gymName}</p>
            <p className="text-xs text-gray-400">Gym</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 bg-green-50 rounded-lg flex items-center justify-center">
                <CalendarCheck className="w-4 h-4 text-green-600" />
              </div>
            </div>
            <p className="text-sm text-gray-800">{monthLogs.length} days</p>
            <p className="text-xs text-gray-400">Attended (This Month)</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-9 h-9 bg-cyan-50 rounded-lg flex items-center justify-center">
                <Calendar className="w-4 h-4 text-cyan-600" />
              </div>
            </div>
            <p className="text-sm text-gray-800">{lastVisit}</p>
            <p className="text-xs text-gray-400">Last Visit</p>
          </CardContent>
        </Card>
      </div>

      {/* Expiry Warning */}
      {daysLeft <= 7 && daysLeft > 0 && (
        <Card className="border-none shadow-sm bg-orange-50 border-l-4 border-l-orange-500">
          <CardContent className="pt-4 pb-3">
            <p className="text-sm text-orange-800">Your membership expires in {daysLeft} days! Contact your gym to renew.</p>
          </CardContent>
        </Card>
      )}
      {daysLeft === 0 && (
        <Card className="border-none shadow-sm bg-red-50 border-l-4 border-l-red-500">
          <CardContent className="pt-4 pb-3">
            <p className="text-sm text-red-800">Your membership has expired! Please renew to continue access.</p>
          </CardContent>
        </Card>
      )}

      {/* Show QR Button */}
      <Button onClick={() => setShowQR(true)} className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white py-6">
        <QrCode className="w-5 h-5 mr-2" /> Show My QR Code
      </Button>

      {/* Renewal Button */}
      {daysLeft <= 30 && (
        <Button variant="outline" className="w-full border-green-500 text-green-600 hover:bg-green-50">
          Renew Membership
        </Button>
      )}

      {/* Full Screen QR */}
      {showQR && (
        <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center p-6">
          <button onClick={() => setShowQR(false)} className="absolute top-4 right-4 w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
            <X className="w-5 h-5 text-gray-600" />
          </button>
          <div className="text-center space-y-6">
            <div>
              <h2 className="text-gray-800">{member.fullName}</h2>
              <p className="text-gray-500 text-sm">ID: {member.memberId}</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-lg inline-block">
              <QRCodeSVG value={member.qrData} size={250} level="H" />
            </div>
            <div className="text-sm text-gray-500 space-y-1">
              <p>{member.planName}</p>
              <p>Expires: {member.endDate}</p>
              <p className={`${expiryColor}`}>{daysLeft} days remaining</p>
            </div>
            <p className="text-xs text-gray-400">Show this QR code at gym entry</p>
          </div>
        </div>
      )}
    </div>
  );
}
