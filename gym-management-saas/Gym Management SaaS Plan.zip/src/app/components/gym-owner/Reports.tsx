import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { useAuth } from '../../context/AuthContext';
import { members, attendanceLogs, payments, attendanceChartData, revenueData } from '../../data/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export function GOReports() {
  const { user } = useAuth();
  const gymId = user?.gymId;
  const gymMembers = members.filter(m => m.gymId === gymId);

  const statusData = [
    { name: 'Active', value: gymMembers.filter(m => m.status === 'active').length, color: '#22c55e' },
    { name: 'Expiring', value: gymMembers.filter(m => m.status === 'expiring').length, color: '#f59e0b' },
    { name: 'Expired', value: gymMembers.filter(m => m.status === 'expired').length, color: '#ef4444' },
  ];

  const planDistribution = gymMembers.reduce((acc, m) => {
    acc[m.planName] = (acc[m.planName] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const planData = Object.entries(planDistribution).map(([name, value]) => ({ name, value }));
  const planColors = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">Reports</h1>
        <p className="text-gray-500 text-sm">Gym performance analytics</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">{gymMembers.length}</p>
            <p className="text-gray-400 text-xs mt-1">Total Members</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-green-600">{gymMembers.filter(m => m.status === 'active').length}</p>
            <p className="text-gray-400 text-xs mt-1">Active</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">
              ₹{(payments.filter(p => p.gymId === gymId && p.type === 'member_subscription').reduce((s, p) => s + p.amount, 0) / 1000).toFixed(0)}K
            </p>
            <p className="text-gray-400 text-xs mt-1">Revenue</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-5 text-center">
            <p className="text-3xl text-gray-800">{attendanceLogs.filter(a => a.gymId === gymId).length}</p>
            <p className="text-gray-400 text-xs mt-1">Total Check-ins</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Weekly Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={attendanceChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Member Status</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" innerRadius={50} outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                  {statusData.map(entry => (
                    <Cell key={entry.name} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Plan Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={planData} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                  {planData.map((_, i) => (
                    <Cell key={i} fill={planColors[i % planColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(val: number) => `₹${val.toLocaleString()}`} />
                <Bar dataKey="revenue" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
