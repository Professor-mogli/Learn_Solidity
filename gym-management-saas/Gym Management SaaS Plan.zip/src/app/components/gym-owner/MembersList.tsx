import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Search, Plus, Edit, Trash2, RotateCw, QrCode, Eye } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { useAuth } from '../../context/AuthContext';
import { members as allMembers, Member } from '../../data/mockData';
import { QRCodeSVG } from 'qrcode.react';
import { toast } from 'sonner';

export function MembersList() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [mems, setMems] = useState<Member[]>(allMembers.filter(m => m.gymId === user?.gymId));
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<string>('all');
  const [qrMember, setQrMember] = useState<Member | null>(null);
  const [viewMember, setViewMember] = useState<Member | null>(null);

  const filtered = mems.filter(m => {
    const matchSearch = m.fullName.toLowerCase().includes(search.toLowerCase()) ||
      m.mobile.includes(search) || m.memberId.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || m.status === filter;
    return matchSearch && matchFilter;
  });

  const deleteMember = (id: string) => {
    setMems(prev => prev.filter(m => m.id !== id));
    toast.success('Member deleted');
  };

  const renewMember = (id: string) => {
    setMems(prev => prev.map(m => {
      if (m.id === id) {
        const newEnd = new Date(m.endDate);
        newEnd.setMonth(newEnd.getMonth() + 3);
        return { ...m, endDate: newEnd.toISOString().split('T')[0], status: 'active' as const };
      }
      return m;
    }));
    toast.success('Membership renewed for 3 months');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-800">Members</h1>
          <p className="text-gray-500 text-sm">{mems.length} total members</p>
        </div>
        <Button onClick={() => navigate('/gym/add-member')} className="bg-blue-500 hover:bg-blue-600 text-white">
          <Plus className="w-4 h-4 mr-2" /> Add Member
        </Button>
      </div>

      <Card className="border-none shadow-sm">
        <CardContent className="pt-5">
          <div className="flex flex-col sm:flex-row gap-3 mb-5">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input placeholder="Search members..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <div className="flex gap-2">
              {['all', 'active', 'expiring', 'expired'].map(f => (
                <Button key={f} variant={filter === f ? 'default' : 'outline'} size="sm"
                  onClick={() => setFilter(f)}
                  className={filter === f ? 'bg-blue-500 hover:bg-blue-600 text-white' : ''}>
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </Button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left py-3 px-3 text-gray-500">Member</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden sm:table-cell">Mobile</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden md:table-cell">Plan</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden lg:table-cell">Start</th>
                  <th className="text-left py-3 px-3 text-gray-500 hidden lg:table-cell">End</th>
                  <th className="text-left py-3 px-3 text-gray-500">Status</th>
                  <th className="text-left py-3 px-3 text-gray-500">QR</th>
                  <th className="text-left py-3 px-3 text-gray-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(mem => (
                  <tr key={mem.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center shrink-0">
                          <span className="text-blue-600 text-xs">{mem.fullName.charAt(0)}</span>
                        </div>
                        <div>
                          <p className="text-gray-800">{mem.fullName}</p>
                          <p className="text-gray-400 text-xs">{mem.memberId}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-gray-600 hidden sm:table-cell">{mem.mobile}</td>
                    <td className="py-3 px-3 text-gray-600 hidden md:table-cell">{mem.planName}</td>
                    <td className="py-3 px-3 text-gray-600 hidden lg:table-cell">{mem.startDate}</td>
                    <td className="py-3 px-3 text-gray-600 hidden lg:table-cell">{mem.endDate}</td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-1 rounded-full text-xs ${
                        mem.status === 'active' ? 'bg-green-100 text-green-700' :
                        mem.status === 'expiring' ? 'bg-orange-100 text-orange-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {mem.status.charAt(0).toUpperCase() + mem.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setQrMember(mem)}>
                        <QrCode className="w-4 h-4 text-gray-500" />
                      </Button>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setViewMember(mem)}>
                          <Eye className="w-4 h-4 text-gray-500" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Edit className="w-4 h-4 text-blue-500" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => renewMember(mem.id)}>
                          <RotateCw className="w-4 h-4 text-green-500" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => deleteMember(mem.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <p className="text-center text-gray-400 py-10">No members found</p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* QR Code Dialog */}
      <Dialog open={!!qrMember} onOpenChange={() => setQrMember(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{qrMember?.fullName}</DialogTitle>
            <DialogDescription>Member QR Code - ID: {qrMember?.memberId}</DialogDescription>
          </DialogHeader>
          {qrMember && (
            <div className="text-center space-y-4">
              <div className="bg-white p-6 rounded-xl inline-block">
                <QRCodeSVG value={qrMember.qrData} size={200} level="H" />
              </div>
              <div className="text-sm text-gray-500">
                <p>Plan: {qrMember.planName}</p>
                <p>Expires: {qrMember.endDate}</p>
                <p className={qrMember.status === 'active' ? 'text-green-600' : qrMember.status === 'expiring' ? 'text-orange-600' : 'text-red-600'}>
                  Status: {qrMember.status.toUpperCase()}
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* View Member Dialog */}
      <Dialog open={!!viewMember} onOpenChange={() => setViewMember(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{viewMember?.fullName}</DialogTitle>
            <DialogDescription>Member details</DialogDescription>
          </DialogHeader>
          {viewMember && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><p className="text-gray-400">Member ID</p><p className="text-gray-800">{viewMember.memberId}</p></div>
                <div><p className="text-gray-400">Mobile</p><p className="text-gray-800">{viewMember.mobile}</p></div>
                <div><p className="text-gray-400">Email</p><p className="text-gray-800">{viewMember.email}</p></div>
                <div><p className="text-gray-400">Plan</p><p className="text-gray-800">{viewMember.planName}</p></div>
                <div><p className="text-gray-400">Start Date</p><p className="text-gray-800">{viewMember.startDate}</p></div>
                <div><p className="text-gray-400">End Date</p><p className="text-gray-800">{viewMember.endDate}</p></div>
                <div><p className="text-gray-400">Status</p><p className={viewMember.status === 'active' ? 'text-green-600' : 'text-red-600'}>{viewMember.status.toUpperCase()}</p></div>
              </div>
              <div><p className="text-gray-400">Address</p><p className="text-gray-800">{viewMember.address}</p></div>
              {viewMember.notes && <div><p className="text-gray-400">Notes</p><p className="text-gray-800">{viewMember.notes}</p></div>}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
