import { useState } from 'react';
import { Save, Building2, Bell } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Switch } from '../ui/switch';
import { useAuth } from '../../context/AuthContext';
import { gymOwners } from '../../data/mockData';
import { toast } from 'sonner';

export function GOSettings() {
  const { user } = useAuth();
  const gym = gymOwners.find(g => g.id === user?.gymId);

  const [gymName, setGymName] = useState(gym?.gymName || '');
  const [address, setAddress] = useState(gym?.address || '');
  const [description, setDescription] = useState(gym?.description || '');
  const [notifExpiry, setNotifExpiry] = useState(true);
  const [notifAttendance, setNotifAttendance] = useState(true);

  return (
    <div className="space-y-6 max-w-3xl">
      <div>
        <h1 className="text-gray-800">Settings</h1>
        <p className="text-gray-500 text-sm">Manage gym profile and preferences</p>
      </div>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700 flex items-center gap-2">
            <Building2 className="w-4 h-4" /> Gym Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Gym Name</label>
            <Input value={gymName} onChange={e => setGymName(e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Address</label>
            <Input value={address} onChange={e => setAddress(e.target.value)} />
          </div>
          <div>
            <label className="text-sm text-gray-600 mb-1.5 block">Description</label>
            <Input value={description} onChange={e => setDescription(e.target.value)} placeholder="Tell members about your gym..." />
          </div>
          <div className="pt-2">
            <p className="text-sm text-gray-500">Subscription: <span className="text-gray-800">{gym?.endDate ? `Active until ${gym.endDate}` : 'N/A'}</span></p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="text-base text-gray-700 flex items-center gap-2">
            <Bell className="w-4 h-4" /> Notifications
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-800">Member Expiry Alerts</p>
              <p className="text-xs text-gray-400">Get notified before member plans expire</p>
            </div>
            <Switch checked={notifExpiry} onCheckedChange={setNotifExpiry} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-800">Daily Attendance Summary</p>
              <p className="text-xs text-gray-400">Receive daily attendance reports</p>
            </div>
            <Switch checked={notifAttendance} onCheckedChange={setNotifAttendance} />
          </div>
        </CardContent>
      </Card>

      <Button onClick={() => toast.success('Settings saved!')} className="bg-blue-500 hover:bg-blue-600 text-white">
        <Save className="w-4 h-4 mr-2" /> Save Settings
      </Button>
    </div>
  );
}
