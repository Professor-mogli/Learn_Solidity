import { useState } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, QrCode, UserPlus } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { useAuth } from '../../context/AuthContext';
import { memberPlans } from '../../data/mockData';
import { QRCodeSVG } from 'qrcode.react';
import { toast } from 'sonner';

export function AddMember() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [created, setCreated] = useState(false);
  const [generatedId, setGeneratedId] = useState('');
  const [qrData, setQrData] = useState('');
  const plans = memberPlans.filter(p => p.gymId === user?.gymId);

  const [form, setForm] = useState({
    fullName: '', mobile: '', email: '', address: '', planId: '', startDate: '', notes: '',
  });

  const update = (k: string, v: string) => setForm(prev => ({ ...prev, [k]: v }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.planId) { toast.error('Please select a plan'); return; }
    const id = `MEM-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
    const plan = plans.find(p => p.id === form.planId);
    const endDate = new Date(form.startDate);
    endDate.setDate(endDate.getDate() + (plan?.durationDays || 30));
    const qr = `${id}|${user?.gymId}|${endDate.toISOString().split('T')[0]}|active`;
    setGeneratedId(id);
    setQrData(qr);
    setCreated(true);
    toast.success(`${form.fullName} has been added as a member!`);
  };

  if (created) {
    return (
      <div className="max-w-lg mx-auto space-y-6 text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
          <UserPlus className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="text-gray-800">Member Added!</h1>
        <p className="text-gray-500 text-sm">{form.fullName} has been registered successfully</p>

        <Card className="border-none shadow-sm">
          <CardContent className="pt-5">
            <div className="space-y-3 text-sm mb-4">
              <div className="grid grid-cols-2 gap-3 text-left">
                <div><p className="text-gray-400">Member ID</p><p className="text-gray-800">{generatedId}</p></div>
                <div><p className="text-gray-400">Name</p><p className="text-gray-800">{form.fullName}</p></div>
                <div><p className="text-gray-400">Plan</p><p className="text-gray-800">{plans.find(p => p.id === form.planId)?.name}</p></div>
                <div><p className="text-gray-400">Start</p><p className="text-gray-800">{form.startDate}</p></div>
              </div>
            </div>
            <div className="bg-gray-50 p-6 rounded-xl">
              <p className="text-gray-500 text-xs mb-3">Member QR Code</p>
              <QRCodeSVG value={qrData} size={180} level="H" className="mx-auto" />
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-3 justify-center">
          <Button variant="outline" onClick={() => { setCreated(false); setForm({ fullName: '', mobile: '', email: '', address: '', planId: '', startDate: '', notes: '' }); }}>
            Add Another
          </Button>
          <Button onClick={() => navigate('/gym/members')} className="bg-blue-500 hover:bg-blue-600 text-white">
            View All Members
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/gym/members')}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-gray-800">Add Member</h1>
          <p className="text-gray-500 text-sm">Register a new gym member</p>
        </div>
      </div>

      <Card className="border-none shadow-sm">
        <CardContent className="pt-5">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Full Name *</label>
                <Input value={form.fullName} onChange={e => update('fullName', e.target.value)} placeholder="Full name" required />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Mobile *</label>
                <Input value={form.mobile} onChange={e => update('mobile', e.target.value)} placeholder="+91 XXXXX XXXXX" required />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Email</label>
                <Input type="email" value={form.email} onChange={e => update('email', e.target.value)} placeholder="email@example.com" />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Address</label>
                <Input value={form.address} onChange={e => update('address', e.target.value)} placeholder="Full address" />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Plan *</label>
                <select value={form.planId} onChange={e => update('planId', e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white" required>
                  <option value="">Select plan</option>
                  {plans.map(p => (
                    <option key={p.id} value={p.id}>{p.name} - ₹{p.price.toLocaleString()} ({p.duration})</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1.5 block">Start Date *</label>
                <Input type="date" value={form.startDate} onChange={e => update('startDate', e.target.value)} required />
              </div>
              <div className="sm:col-span-2">
                <label className="text-sm text-gray-600 mb-1.5 block">Notes</label>
                <Input value={form.notes} onChange={e => update('notes', e.target.value)} placeholder="Any additional notes..." />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button type="button" variant="outline" onClick={() => navigate('/gym/members')}>Cancel</Button>
              <Button type="submit" className="bg-blue-500 hover:bg-blue-600 text-white">
                <UserPlus className="w-4 h-4 mr-2" /> Save Member
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
