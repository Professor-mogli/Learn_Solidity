import { useState } from 'react';
import { ScanLine, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { useAuth } from '../../context/AuthContext';
import { members } from '../../data/mockData';
import { motion } from 'motion/react';

type ScanResult = { type: 'granted' | 'expired' | 'denied'; memberName?: string; memberId?: string; plan?: string; expiry?: string; message: string };

export function QRScanner() {
  const { user } = useAuth();
  const [scanning, setScanning] = useState(false);
  const [manualId, setManualId] = useState('');
  const [result, setResult] = useState<ScanResult | null>(null);

  const simulateScan = (memberId?: string) => {
    setScanning(true);
    setResult(null);

    setTimeout(() => {
      const id = memberId || manualId.trim();
      const member = members.find(m => (m.memberId === id || m.id === id) && m.gymId === user?.gymId);

      if (!member) {
        setResult({ type: 'denied', message: 'Member not found or does not belong to this gym' });
      } else if (member.status === 'expired') {
        setResult({ type: 'expired', memberName: member.fullName, memberId: member.memberId, plan: member.planName, expiry: member.endDate, message: 'SUBSCRIPTION EXPIRED' });
      } else {
        setResult({ type: 'granted', memberName: member.fullName, memberId: member.memberId, plan: member.planName, expiry: member.endDate, message: 'ACCESS GRANTED' });
      }
      setScanning(false);
    }, 1500);
  };

  const quickScanMember = () => {
    const gymMembers = members.filter(m => m.gymId === user?.gymId && m.status === 'active');
    const randomMember = gymMembers[Math.floor(Math.random() * gymMembers.length)];
    if (randomMember) simulateScan(randomMember.memberId);
  };

  const scanExpired = () => {
    const expired = members.find(m => m.gymId === user?.gymId && m.status === 'expired');
    if (expired) simulateScan(expired.memberId);
  };

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <div className="text-center">
        <h1 className="text-gray-800">QR Scanner</h1>
        <p className="text-gray-500 text-sm">Scan member QR codes for entry</p>
      </div>

      {/* Scanner Area */}
      <Card className="border-none shadow-sm overflow-hidden">
        <CardContent className="pt-5">
          <div className="bg-gray-900 rounded-xl p-8 text-center relative overflow-hidden">
            {scanning ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-4"
              >
                <motion.div
                  animate={{ y: [0, 120, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-48 h-0.5 bg-blue-500 mx-auto"
                />
                <ScanLine className="w-16 h-16 text-blue-400 mx-auto" />
                <p className="text-white text-sm">Scanning...</p>
              </motion.div>
            ) : result ? (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="space-y-3"
              >
                {result.type === 'granted' ? (
                  <div className="space-y-3">
                    <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle className="w-10 h-10 text-white" />
                    </div>
                    <p className="text-green-400 text-xl">{result.message}</p>
                    <div className="text-gray-300 text-sm space-y-1">
                      <p>{result.memberName}</p>
                      <p className="text-gray-400">ID: {result.memberId}</p>
                      <p className="text-gray-400">Plan: {result.plan}</p>
                      <p className="text-gray-400">Expires: {result.expiry}</p>
                    </div>
                  </div>
                ) : result.type === 'expired' ? (
                  <div className="space-y-3">
                    <div className="w-20 h-20 bg-red-500 rounded-full flex items-center justify-center mx-auto">
                      <XCircle className="w-10 h-10 text-white" />
                    </div>
                    <p className="text-red-400 text-xl">{result.message}</p>
                    <div className="text-gray-300 text-sm space-y-1">
                      <p>{result.memberName}</p>
                      <p className="text-gray-400">ID: {result.memberId}</p>
                      <p className="text-gray-400">Expired: {result.expiry}</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center mx-auto">
                      <AlertCircle className="w-10 h-10 text-white" />
                    </div>
                    <p className="text-orange-400 text-xl">ACCESS DENIED</p>
                    <p className="text-gray-400 text-sm">{result.message}</p>
                  </div>
                )}
              </motion.div>
            ) : (
              <div className="space-y-4">
                <div className="w-32 h-32 border-2 border-dashed border-gray-600 rounded-xl mx-auto flex items-center justify-center">
                  <ScanLine className="w-12 h-12 text-gray-500" />
                </div>
                <p className="text-gray-400 text-sm">Ready to scan</p>
              </div>
            )}
          </div>

          <div className="mt-4 space-y-3">
            <div className="flex gap-2">
              <Input
                placeholder="Enter Member ID manually"
                value={manualId}
                onChange={e => setManualId(e.target.value)}
              />
              <Button onClick={() => simulateScan()} className="bg-blue-500 hover:bg-blue-600 text-white shrink-0">
                Verify
              </Button>
            </div>

            <div className="flex gap-2">
              <Button onClick={quickScanMember} variant="outline" className="flex-1">
                Simulate Active Scan
              </Button>
              <Button onClick={scanExpired} variant="outline" className="flex-1 text-red-500 border-red-200 hover:bg-red-50">
                Simulate Expired Scan
              </Button>
            </div>

            {result && (
              <Button variant="outline" className="w-full" onClick={() => { setResult(null); setManualId(''); }}>
                Scan Next
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
