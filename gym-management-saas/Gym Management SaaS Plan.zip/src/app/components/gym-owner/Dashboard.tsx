import { Users, UserCheck, Clock, ScanLine, DollarSign, TrendingUp, CalendarCheck, Trophy } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { useAuth } from '../../context/AuthContext';
import { members, attendanceLogs, payments, attendanceChartData, revenueData } from '../../data/mockData';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';

export function GODashboard() {
  const { user } = useAuth();
  const gymId = user?.gymId;
  const gymMembers = members.filter(m => m.gymId === gymId);
  const activeMembers = gymMembers.filter(m => m.status === 'active').length;
  const expiring = gymMembers.filter(m => m.status === 'expiring').length;
  const todayStr = '2026-02-18';
  const todayAttendance = attendanceLogs.filter(a => a.gymId === gymId && a.date === todayStr);
  const monthAttendance = attendanceLogs.filter(a => a.gymId === gymId && a.date.startsWith('2026-02'));
  const gymPayments = payments.filter(p => p.gymId === gymId && p.type === 'member_subscription');
  const revenue = gymPayments.reduce((s, p) => s + p.amount, 0);

  // Most active members this month
  const memberAttCount: Record<string, { name: string; count: number }> = {};
  monthAttendance.forEach(a => {
    if (!memberAttCount[a.memberId]) memberAttCount[a.memberId] = { name: a.memberName, count: 0 };
    memberAttCount[a.memberId].count++;
  });
  const topMembers = Object.values(memberAttCount).sort((a, b) => b.count - a.count).slice(0, 5);

  const cards = [
    { label: 'Total Members', value: gymMembers.length, icon: Users, color: 'bg-blue-50 text-blue-600' },
    { label: 'Active Members', value: activeMembers, icon: UserCheck, color: 'bg-green-50 text-green-600' },
    { label: 'Expiring Soon', value: expiring, icon: Clock, color: 'bg-orange-50 text-orange-600' },
    { label: "Today's Entries", value: todayAttendance.length, icon: ScanLine, color: 'bg-purple-50 text-purple-600' },
    { label: 'Monthly Attendance', value: monthAttendance.length, icon: CalendarCheck, color: 'bg-cyan-50 text-cyan-600' },
    { label: 'Revenue', value: `₹${(revenue / 1000).toFixed(1)}K`, icon: DollarSign, color: 'bg-emerald-50 text-emerald-600' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-800">Dashboard</h1>
        <p className="text-gray-500 text-sm">Welcome back, {user?.name}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {cards.map(({ label, value, icon: Icon, color }) => (
          <Card key={label} className="border-none shadow-sm">
            <CardContent className="pt-4 pb-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${color} mb-2`}>
                <Icon className="w-4 h-4" />
              </div>
              <p className="text-xl text-gray-800">{value}</p>
              <p className="text-gray-400 text-xs">{label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Weekly Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={attendanceChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip formatter={(val: number) => `₹${val.toLocaleString()}`} />
                <Area type="monotone" dataKey="revenue" stroke="#10b981" fill="#d1fae5" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-orange-500" /> Most Active Members
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topMembers.map((m, i) => (
                <div key={m.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs ${
                      i === 0 ? 'bg-yellow-100 text-yellow-700' :
                      i === 1 ? 'bg-gray-100 text-gray-600' :
                      i === 2 ? 'bg-orange-100 text-orange-600' :
                      'bg-gray-50 text-gray-500'
                    }`}>{i + 1}</span>
                    <span className="text-sm text-gray-700">{m.name}</span>
                  </div>
                  <span className="text-sm text-gray-500">{m.count} days</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Today's Check-ins</CardTitle>
          </CardHeader>
          <CardContent>
            {todayAttendance.length > 0 ? (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {todayAttendance.map(a => (
                  <div key={a.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                        <span className="text-green-600 text-xs">{a.memberName.charAt(0)}</span>
                      </div>
                      <span className="text-sm text-gray-700">{a.memberName}</span>
                    </div>
                    <span className="text-xs text-gray-400">{a.checkInTime}</span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-sm text-center py-8">No check-ins today yet</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
