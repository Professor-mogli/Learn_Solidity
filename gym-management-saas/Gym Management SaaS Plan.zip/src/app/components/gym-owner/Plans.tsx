import { useState } from 'react';
import { Plus, Edit, Trash2, Check } from 'lucide-react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { useAuth } from '../../context/AuthContext';
import { memberPlans as initialPlans, MemberPlan } from '../../data/mockData';
import { toast } from 'sonner';

export function GOPlans() {
  const { user } = useAuth();
  const [plans, setPlans] = useState<MemberPlan[]>(initialPlans.filter(p => p.gymId === user?.gymId));
  const [showCreate, setShowCreate] = useState(false);
  const [editPlan, setEditPlan] = useState<MemberPlan | null>(null);
  const [form, setForm] = useState({ name: '', duration: '', durationDays: '', price: '', features: '' });

  const resetForm = () => setForm({ name: '', duration: '', durationDays: '', price: '', features: '' });

  const openEdit = (plan: MemberPlan) => {
    setEditPlan(plan);
    setForm({
      name: plan.name, duration: plan.duration, durationDays: String(plan.durationDays),
      price: String(plan.price), features: plan.features.join(', '),
    });
    setShowCreate(true);
  };

  const handleSave = () => {
    const newPlan: MemberPlan = {
      id: editPlan?.id || `mplan-${Date.now()}`,
      gymId: user?.gymId || '',
      name: form.name, duration: form.duration, durationDays: Number(form.durationDays),
      price: Number(form.price),
      features: form.features.split(',').map(f => f.trim()).filter(Boolean),
      status: 'active',
    };
    if (editPlan) {
      setPlans(prev => prev.map(p => p.id === editPlan.id ? newPlan : p));
      toast.success('Plan updated!');
    } else {
      setPlans(prev => [...prev, newPlan]);
      toast.success('Plan created!');
    }
    setShowCreate(false);
    setEditPlan(null);
    resetForm();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-800">Subscription Plans</h1>
          <p className="text-gray-500 text-sm">Manage membership plans for your gym</p>
        </div>
        <Button onClick={() => { resetForm(); setEditPlan(null); setShowCreate(true); }} className="bg-blue-500 hover:bg-blue-600 text-white">
          <Plus className="w-4 h-4 mr-2" /> Create Plan
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map(plan => (
          <Card key={plan.id} className="border-none shadow-sm">
            <CardContent className="pt-5">
              <h3 className="text-gray-800 mb-1">{plan.name}</h3>
              <p className="text-3xl text-gray-800">₹{plan.price.toLocaleString()}</p>
              <p className="text-gray-400 text-xs mb-4">{plan.duration} ({plan.durationDays} days)</p>
              <ul className="space-y-2 mb-4">
                {plan.features.map((f, i) => (
                  <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-green-500 shrink-0" /> {f}
                  </li>
                ))}
              </ul>
              <div className="flex gap-2 pt-3 border-t">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => openEdit(plan)}>
                  <Edit className="w-3 h-3 mr-1" /> Edit
                </Button>
                <Button size="sm" variant="outline" className="text-red-500"
                  onClick={() => { setPlans(prev => prev.filter(p => p.id !== plan.id)); toast.success('Plan deleted'); }}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editPlan ? 'Edit Plan' : 'Create Plan'}</DialogTitle>
            <DialogDescription>Configure plan details</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-600 mb-1 block">Plan Name</label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g., Premium Plan" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm text-gray-600 mb-1 block">Duration Label</label>
                <Input value={form.duration} onChange={e => setForm({ ...form, duration: e.target.value })} placeholder="e.g., 3 Months" />
              </div>
              <div>
                <label className="text-sm text-gray-600 mb-1 block">Duration (Days)</label>
                <Input type="number" value={form.durationDays} onChange={e => setForm({ ...form, durationDays: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-600 mb-1 block">Price (₹)</label>
              <Input type="number" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
            </div>
            <div>
              <label className="text-sm text-gray-600 mb-1 block">Features (comma separated)</label>
              <Input value={form.features} onChange={e => setForm({ ...form, features: e.target.value })} placeholder="Feature 1, Feature 2" />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button onClick={handleSave} className="bg-blue-500 hover:bg-blue-600 text-white">
                {editPlan ? 'Update' : 'Create'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
