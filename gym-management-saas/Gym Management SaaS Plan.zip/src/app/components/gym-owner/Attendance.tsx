import { useState, useMemo } from 'react';
import { Search, CalendarDays, Users, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../ui/dialog';
import { useAuth } from '../../context/AuthContext';
import { attendanceLogs, members } from '../../data/mockData';

export function GOAttendance() {
  const { user } = useAuth();
  const gymId = user?.gymId;
  const [selectedDate, setSelectedDate] = useState('2026-02-18');
  const [selectedMonth, setSelectedMonth] = useState('2026-02');
  const [searchMember, setSearchMember] = useState('');
  const [viewMode, setViewMode] = useState<'today' | 'monthly' | 'member'>('today');
  const [selectedMember, setSelectedMember] = useState<string | null>(null);

  const gymLogs = attendanceLogs.filter(a => a.gymId === gymId);
  const todayLogs = gymLogs.filter(a => a.date === selectedDate);
  const monthLogs = gymLogs.filter(a => a.date.startsWith(selectedMonth));

  const gymMembers = members.filter(m => m.gymId === gymId);

  const memberDetail = useMemo(() => {
    if (!selectedMember) return null;
    const mem = gymMembers.find(m => m.id === selectedMember);
    if (!mem) return null;
    const logs = gymLogs.filter(a => a.memberId === selectedMember && a.date.startsWith(selectedMonth));
    const daysInMonth = new Date(parseInt(selectedMonth.split('-')[0]), parseInt(selectedMonth.split('-')[1]), 0).getDate();
    const today = 18; // Current day
    const totalDays = Math.min(today, daysInMonth);
    const attended = logs.length;
    const percentage = totalDays > 0 ? Math.round((attended / totalDays) * 100) : 0;
    const lastVisit = logs.length > 0 ? logs[logs.length - 1].date : 'N/A';

    // Calendar data
    const calendarDays: { day: number; status: 'present' | 'absent' | 'none' }[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dateStr = `${selectedMonth}-${d.toString().padStart(2, '0')}`;
      if (d > today) {
        calendarDays.push({ day: d, status: 'none' });
      } else if (logs.some(l => l.date === dateStr)) {
        calendarDays.push({ day: d, status: 'present' });
      } else {
        calendarDays.push({ day: d, status: 'absent' });
      }
    }

    return { member: mem, attended, missed: totalDays - attended, percentage, lastVisit, calendarDays, logs };
  }, [selectedMember, selectedMonth, gymLogs, gymMembers]);

  const filteredTodayLogs = todayLogs.filter(a =>
    a.memberName.toLowerCase().includes(searchMember.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-gray-800">Attendance</h1>
          <p className="text-gray-500 text-sm">Track member attendance and check-ins</p>
        </div>
        <div className="flex gap-2">
          {(['today', 'monthly', 'member'] as const).map(mode => (
            <Button key={mode} variant={viewMode === mode ? 'default' : 'outline'} size="sm"
              onClick={() => setViewMode(mode)}
              className={viewMode === mode ? 'bg-blue-500 hover:bg-blue-600 text-white' : ''}>
              {mode.charAt(0).toUpperCase() + mode.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <p className="text-2xl text-gray-800">{todayLogs.length}</p>
            <p className="text-gray-400 text-xs">Today's Count</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <p className="text-2xl text-gray-800">{monthLogs.length}</p>
            <p className="text-gray-400 text-xs">Monthly Total</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <p className="text-2xl text-gray-800">{gymMembers.length}</p>
            <p className="text-gray-400 text-xs">Total Members</p>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm">
          <CardContent className="pt-4 pb-3">
            <p className="text-2xl text-gray-800">{Math.round((todayLogs.length / Math.max(gymMembers.length, 1)) * 100)}%</p>
            <p className="text-gray-400 text-xs">Today's Rate</p>
          </CardContent>
        </Card>
      </div>

      {viewMode === 'today' && (
        <Card className="border-none shadow-sm">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <CardTitle className="text-base text-gray-700">Today's Attendance</CardTitle>
              <div className="flex gap-2">
                <Input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="w-auto" />
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input placeholder="Search..." value={searchMember} onChange={e => setSearchMember(e.target.value)} className="pl-9" />
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left py-3 px-3 text-gray-500">Member</th>
                    <th className="text-left py-3 px-3 text-gray-500">Time</th>
                    <th className="text-left py-3 px-3 text-gray-500">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTodayLogs.map(log => (
                    <tr key={log.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <span className="text-green-600 text-xs">{log.memberName.charAt(0)}</span>
                          </div>
                          <span className="text-gray-800">{log.memberName}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-gray-600">{log.checkInTime}</td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-700">Present</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {filteredTodayLogs.length === 0 && (
                <p className="text-center text-gray-400 py-10">No attendance records for this date</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {viewMode === 'monthly' && (
        <Card className="border-none shadow-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base text-gray-700">Monthly Overview</CardTitle>
              <Input type="month" value={selectedMonth} onChange={e => setSelectedMonth(e.target.value)} className="w-auto" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left py-3 px-3 text-gray-500">Member</th>
                    <th className="text-left py-3 px-3 text-gray-500">Days Present</th>
                    <th className="text-left py-3 px-3 text-gray-500">Attendance %</th>
                    <th className="text-left py-3 px-3 text-gray-500">Last Visit</th>
                    <th className="text-left py-3 px-3 text-gray-500">Details</th>
                  </tr>
                </thead>
                <tbody>
                  {gymMembers.map(mem => {
                    const logs = monthLogs.filter(a => a.memberId === mem.id);
                    const pct = Math.round((logs.length / 18) * 100);
                    const last = logs.length > 0 ? logs[logs.length - 1].date : 'N/A';
                    return (
                      <tr key={mem.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-blue-600 text-xs">{mem.fullName.charAt(0)}</span>
                            </div>
                            <span className="text-gray-800">{mem.fullName}</span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-gray-600">{logs.length} days</td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-2 bg-gray-100 rounded-full overflow-hidden">
                              <div className={`h-full rounded-full ${pct >= 70 ? 'bg-green-500' : pct >= 40 ? 'bg-orange-500' : 'bg-red-500'}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                            </div>
                            <span className="text-xs text-gray-500">{pct}%</span>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-gray-600 text-xs">{last}</td>
                        <td className="py-3 px-3">
                          <Button variant="ghost" size="sm" onClick={() => { setSelectedMember(mem.id); }}>
                            View
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {viewMode === 'member' && (
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-base text-gray-700">Select a Member</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {gymMembers.map(mem => (
                <button
                  key={mem.id}
                  onClick={() => setSelectedMember(mem.id)}
                  className={`p-3 rounded-xl border text-left transition-colors ${
                    selectedMember === mem.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 text-sm">{mem.fullName.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="text-sm text-gray-800">{mem.fullName}</p>
                      <p className="text-xs text-gray-400">{mem.memberId}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Member Detail Dialog */}
      <Dialog open={!!selectedMember && !!memberDetail} onOpenChange={() => setSelectedMember(null)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{memberDetail?.member.fullName} - Attendance</DialogTitle>
            <DialogDescription>Monthly attendance details</DialogDescription>
          </DialogHeader>
          {memberDetail && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <div className="bg-green-50 rounded-xl p-3 text-center">
                  <p className="text-xl text-green-700">{memberDetail.attended}</p>
                  <p className="text-xs text-green-600">Present</p>
                </div>
                <div className="bg-red-50 rounded-xl p-3 text-center">
                  <p className="text-xl text-red-700">{memberDetail.missed}</p>
                  <p className="text-xs text-red-600">Missed</p>
                </div>
                <div className="bg-blue-50 rounded-xl p-3 text-center">
                  <p className="text-xl text-blue-700">{memberDetail.percentage}%</p>
                  <p className="text-xs text-blue-600">Rate</p>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-2">Calendar View - {selectedMonth}</p>
                <div className="grid grid-cols-7 gap-1.5 text-center">
                  {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
                    <span key={i} className="text-xs text-gray-400 py-1">{d}</span>
                  ))}
                  {/* Empty cells for first day offset */}
                  {Array.from({ length: new Date(`${selectedMonth}-01`).getDay() }).map((_, i) => (
                    <span key={`empty-${i}`} />
                  ))}
                  {memberDetail.calendarDays.map(({ day, status }) => (
                    <span
                      key={day}
                      className={`w-8 h-8 rounded-full flex items-center justify-center text-xs mx-auto ${
                        status === 'present' ? 'bg-green-500 text-white' :
                        status === 'absent' ? 'bg-red-100 text-red-600' :
                        'bg-gray-50 text-gray-300'
                      }`}
                    >
                      {day}
                    </span>
                  ))}
                </div>
                <div className="flex gap-4 mt-3 text-xs text-gray-400 justify-center">
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-green-500" /> Present</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-red-100" /> Absent</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-gray-50 border" /> Future</span>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-500 mb-2">Last Visit: {memberDetail.lastVisit}</p>
              </div>

              {memberDetail.logs.length > 0 && (
                <div>
                  <p className="text-sm text-gray-500 mb-2">Check-in History</p>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {memberDetail.logs.map(log => (
                      <div key={log.id} className="flex items-center justify-between py-1.5 text-sm border-b border-gray-50">
                        <span className="text-gray-600">{log.date}</span>
                        <span className="text-gray-400">{log.checkInTime}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
