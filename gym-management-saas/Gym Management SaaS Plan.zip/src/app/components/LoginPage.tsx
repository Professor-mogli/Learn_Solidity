import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth, UserRole } from '../context/AuthContext';
import { Dumbbell, Shield, Building2, User, Eye, EyeOff, Smartphone } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { toast } from 'sonner';

export function LoginPage() {
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { login, memberLogin } = useAuth();
  const navigate = useNavigate();

  const roleCards = [
    { role: 'super_admin' as UserRole, icon: Shield, label: 'Super Admin', desc: 'Full platform control', color: 'bg-purple-500' },
    { role: 'gym_owner' as UserRole, icon: Building2, label: 'Gym Owner', desc: 'Manage your gym', color: 'bg-blue-500' },
    { role: 'member' as UserRole, icon: User, label: 'Member', desc: 'View membership', color: 'bg-green-500' },
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedRole === 'member') {
      if (!otpSent) {
        setOtpSent(true);
        toast.success('OTP sent to your mobile number! (Use any 4 digits for demo)');
        return;
      }
      if (otp.length === 4) {
        const success = memberLogin(mobile);
        if (success) {
          toast.success('Welcome back!');
          navigate('/member');
        } else {
          toast.error('Mobile number not found or membership expired');
        }
      }
      return;
    }

    const success = login(email, password, selectedRole!);
    if (success) {
      toast.success('Login successful!');
      navigate(selectedRole === 'super_admin' ? '/admin' : '/gym');
    } else {
      toast.error('Invalid credentials or account inactive');
    }
  };

  const prefillCredentials = () => {
    if (selectedRole === 'super_admin') {
      setEmail('admin@gymmanager.com');
      setPassword('admin123');
    } else if (selectedRole === 'gym_owner') {
      setEmail('rajesh@ironfit.com');
      setPassword('gym123');
    } else if (selectedRole === 'member') {
      setMobile('9988776655');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl mb-4">
            <Dumbbell className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-white mb-1">GymManager Pro</h1>
          <p className="text-gray-400">Complete Gym Management Platform</p>
        </div>

        {!selectedRole ? (
          <div className="space-y-3">
            <p className="text-gray-300 text-center mb-4">Select your role to continue</p>
            {roleCards.map(({ role, icon: Icon, label, desc, color }) => (
              <button
                key={role}
                onClick={() => setSelectedRole(role)}
                className="w-full flex items-center gap-4 p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl transition-all"
              >
                <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-white">{label}</p>
                  <p className="text-gray-400 text-sm">{desc}</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 ${roleCards.find(r => r.role === selectedRole)?.color} rounded-xl flex items-center justify-center`}>
                    {React.createElement(roleCards.find(r => r.role === selectedRole)!.icon, { className: 'w-5 h-5 text-white' })}
                  </div>
                  <div>
                    <CardTitle className="text-white">{roleCards.find(r => r.role === selectedRole)?.label} Login</CardTitle>
                    <CardDescription className="text-gray-400">Enter your credentials</CardDescription>
                  </div>
                </div>
                <button onClick={() => { setSelectedRole(null); setOtpSent(false); }} className="text-gray-400 hover:text-white text-sm">
                  Change Role
                </button>
              </div>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                {selectedRole === 'member' ? (
                  <>
                    <div>
                      <label className="text-gray-300 text-sm mb-1.5 block">Mobile Number</label>
                      <div className="relative">
                        <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <Input
                          type="tel"
                          placeholder="Enter mobile number"
                          value={mobile}
                          onChange={e => setMobile(e.target.value)}
                          className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                          disabled={otpSent}
                          required
                        />
                      </div>
                    </div>
                    {otpSent && (
                      <div>
                        <label className="text-gray-300 text-sm mb-1.5 block">Enter OTP</label>
                        <Input
                          type="text"
                          placeholder="Enter 4-digit OTP"
                          value={otp}
                          onChange={e => setOtp(e.target.value.slice(0, 4))}
                          className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 tracking-widest text-center"
                          maxLength={4}
                          required
                        />
                      </div>
                    )}
                  </>
                ) : (
                  <>
                    <div>
                      <label className="text-gray-300 text-sm mb-1.5 block">Email</label>
                      <Input
                        type="email"
                        placeholder="Enter your email"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-gray-300 text-sm mb-1.5 block">Password</label>
                      <div className="relative">
                        <Input
                          type={showPassword ? 'text' : 'password'}
                          placeholder="Enter password"
                          value={password}
                          onChange={e => setPassword(e.target.value)}
                          className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pr-10"
                          required
                        />
                        <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
                          {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>
                  </>
                )}
                <Button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white">
                  {selectedRole === 'member' ? (otpSent ? 'Verify OTP' : 'Send OTP') : 'Login'}
                </Button>
              </form>
              <button onClick={prefillCredentials} className="w-full mt-3 text-sm text-orange-400 hover:text-orange-300 transition-colors">
                Use demo credentials
              </button>
            </CardContent>
          </Card>
        )}

        <p className="text-center text-gray-500 text-xs mt-6">
          Demo Credentials: admin@gymmanager.com / admin123
        </p>
      </div>
    </div>
  );
}
