import { createBrowserRouter, Navigate } from 'react-router';
import { LoginPage } from './components/LoginPage';
import { SuperAdminLayout } from './components/layouts/SuperAdminLayout';
import { GymOwnerLayout } from './components/layouts/GymOwnerLayout';
import { MemberLayout } from './components/layouts/MemberLayout';
import { SADashboard } from './components/super-admin/Dashboard';
import { GymOwnersList } from './components/super-admin/GymOwnersList';
import { CreateGymOwner } from './components/super-admin/CreateGymOwner';
import { SASubscriptionPacks } from './components/super-admin/SubscriptionPacks';
import { SAPayments } from './components/super-admin/Payments';
import { SAReports } from './components/super-admin/Reports';
import { SASettings } from './components/super-admin/Settings';
import { GODashboard } from './components/gym-owner/Dashboard';
import { MembersList } from './components/gym-owner/MembersList';
import { AddMember } from './components/gym-owner/AddMember';
import { GOAttendance } from './components/gym-owner/Attendance';
import { QRScanner } from './components/gym-owner/QRScanner';
import { GOPlans } from './components/gym-owner/Plans';
import { GOReports } from './components/gym-owner/Reports';
import { GOSettings } from './components/gym-owner/Settings';
import { MemberDashboard } from './components/member/Dashboard';
import { MemberAttendancePage } from './components/member/AttendancePage';
import { MemberProfile } from './components/member/Profile';
import { NotFound } from './components/NotFound';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: LoginPage,
  },
  // Super Admin Routes
  {
    path: '/admin',
    Component: SuperAdminLayout,
    children: [
      { index: true, Component: SADashboard },
      { path: 'gym-owners', Component: GymOwnersList },
      { path: 'gym-owners/create', Component: CreateGymOwner },
      { path: 'gym-owners/edit/:id', Component: CreateGymOwner },
      { path: 'packs', Component: SASubscriptionPacks },
      { path: 'payments', Component: SAPayments },
      { path: 'reports', Component: SAReports },
      { path: 'settings', Component: SASettings },
    ],
  },
  // Gym Owner Routes
  {
    path: '/gym',
    Component: GymOwnerLayout,
    children: [
      { index: true, Component: GODashboard },
      { path: 'members', Component: MembersList },
      { path: 'add-member', Component: AddMember },
      { path: 'attendance', Component: GOAttendance },
      { path: 'qr-scan', Component: QRScanner },
      { path: 'plans', Component: GOPlans },
      { path: 'reports', Component: GOReports },
      { path: 'settings', Component: GOSettings },
    ],
  },
  // Member Routes
  {
    path: '/member',
    Component: MemberLayout,
    children: [
      { index: true, Component: MemberDashboard },
      { path: 'attendance', Component: MemberAttendancePage },
      { path: 'profile', Component: MemberProfile },
    ],
  },
  {
    path: '*',
    Component: NotFound,
  },
]);
